﻿using System;
using System.IO.Ports;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Controls;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using MB;



namespace AnemoWin
{    // public class Graph 
    public partial class MainWindow : Window
    {
        //public ProgressBar memo;
        public static float AV;
        public double fa0, fa1;
        public static double fimi;
        public static int brr, testb;
        public static TimeSpan longtime, shortime;
        public PlotModel MyModel { get; private set; }//OxyPlot function
        public static bool VACT, VOLT, ADT;
        public const int SAMPS = 20;// 25;
        public const int SAMPANA =  40;
        public const int CH = 3;
        public static bool[] axes = new bool[CH];
        public static byte[]rgb  = new byte[CH];
        public const int SAMPA = 120;//=SAMPANA*CH
        public static int HR = 650;
        public static int NR;
        public static Int16[,] A;
        public static Single[,] F;
        public OxyPlot.Series.LineSeries[] s = new OxyPlot.Series.LineSeries[CH];//OxyPlot function
        public OxyPlot.Series.LineSeries[] sa = new OxyPlot.Series.LineSeries[CH];//OxyPlot function
        public OxyPlot.Series.LineSeries sf = new OxyPlot.Series.LineSeries();//OxyPlot function
        public OxyPlot.Series.LineSeries sg = new OxyPlot.Series.LineSeries();//OxyPlot function
        public static float MAXVEL = 56;
        public const double ABSMAXVEL = 60;
        public const double MAXANA = 2048;
        public const double KATIM = 0.25; //0.3185;
        public const double QARTER = 6.25;//(SAMPS * KATIM); 
        public static int  i, j, k, q=-1;
        public static bool STOP = false, SELFT = false, CLICK = false, GX = false, GY = false, GU = false, GWM=false,WAIT=false;
        public static bool SETPLOT = false;//t
        public static DispatcherTimer ScanTimer;
        string x, y;
        public double sum0, sum1;
        public static int MAXS = 26000;
        public delegate void req(byte unitId, byte funCode, ushort startAdr, ushort quantity);
        public event req MBreq ;
        public static uint nreq, nresp, nana;
        public static Int16 errorsrec;  //t
        public void Graph()
        {
          //  VACT  = true;//!!!test!!!
          //  VOLT = false;//!!!test!!!
            NR = HR / SAMPS;
            A = new Int16[SAMPA, CH];
            F = new Single[SAMPS, CH];
            x = SAMPA.ToString("-000000");
            y = KATIM.ToString("-0.0000");
            MyModel = new PlotModel
            {//OxyPlot function
                Title = "Wind speed[m/s]",
            };
            
            MyModel.Title = "Amplified Receiver voltages[ADC bits]";
            MyModel.Axes.Clear();
            MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Minimum = 0, Maximum = SAMPA * KATIM, AbsoluteMinimum = 0, AbsoluteMaximum = SAMPA * KATIM }); ;
            MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Minimum = -MAXANA, Maximum = MAXANA, AbsoluteMinimum = -MAXANA, AbsoluteMaximum = MAXANA });
 
            MyModel.Series.Clear();
            MyModel.Axes[0].Minimum = 0;//t
            MyModel.Axes[0].Maximum = HR / 100;
            MyModel.Axes[1].Minimum = -MAXVEL;
            MyModel.Axes[1].Maximum = MAXVEL;
            MyModel.Axes[0].AbsoluteMinimum = 0;//t
            MyModel.Axes[0].AbsoluteMaximum = HR / 100;
            MyModel.Axes[1].AbsoluteMinimum = -ABSMAXVEL;
            MyModel.Axes[1].AbsoluteMaximum = ABSMAXVEL;

            for (i = 0; i < CH; i++)
            {
                s[i] = new OxyPlot.Series.LineSeries();//OxyPlot function...
                for (int ix = 0; ix < 3; ix++)
                {
                    if (ix == i) rgb[ix] = 0xff;
                    else rgb[ix] = 0;
                }
                s[i].Color = OxyColor.FromRgb(rgb[0], rgb[1], rgb[2]);
                s[i].Title = "V" + i.ToString(); 
                s[i].StrokeThickness = 1.5;
                 MyModel.Series.Add(s[i]);
            }
           
            sf.Points.Add(new DataPoint(0, MAXVEL));
            sf.Points.Add(new DataPoint(0, -MAXVEL));
            sf.Points.Add(new DataPoint(0, 0));
            sf.Points.Add(new DataPoint(HR, 0));
            sf.StrokeThickness = 1;
            this.MyModel.Series.Add(sf);
            
         
            for (i = 0; i < CH; i++)
            {
                sa[i] = new OxyPlot.Series.LineSeries();//OxyPlot function...
                for (int ix = 0; ix < 3; ix++)
                {
                    if (ix == i) rgb[ix] = 0xff;
                    else rgb[ix] = 0;
                }
                sa[i].Color = OxyColor.FromRgb(rgb[0], rgb[1], rgb[2]);
                sa[i].Title = "Axe" + i.ToString();
                sa[i].StrokeThickness = 1.5;
                MyModel.Series.Add(sa[i]);
            }
            sg = new OxyPlot.Series.LineSeries();//OxyPlot function...               
            sg.StrokeThickness = 1.5;
            MyModel.Series.Add(sg);
   //         sg.Points.Add(new DataPoint(0, MAXANA));
   //         sg.Points.Add(new DataPoint(0, -MAXANA));
   //         sg.Points.Add(new DataPoint(0, 0));
   //         sg.Points.Add(new DataPoint(SAMPA * KATIM, 0));
            sg.StrokeThickness = 1;//...OxyPlot function
            ScanTimer = new DispatcherTimer();
            ScanTimer.Tick += new EventHandler(ScanTimer_Tick);
            ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, 200);//  200ms interval
           // ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, 250);//  250ms interval
            ScanTimer.Start();//t
        }
       

        public static  double Abs(double x, double y)
        {
            return Math.Sqrt(x * x + y * y);
        }

        public void ScanTimer_Tick(object sender, EventArgs et)
        {
            try
            {
                if (B.CRCERR || !ser.serial.IsOpen)
                    errorsrec++;
                else errorsrec = 0;
                if (errorsrec > 10)
                {
                    errorsrec = 0;
                    
                    ser.OpenCOM();
                    if (ser.serial.IsOpen)
                        COM.Background = Brushes.LightGreen;
                    else
                        COM.Background = Brushes.Pink;
                    COM.Content = MB.ser.serial.PortName;
                    WAIT = false;//t
                   
                }
                axes[0] = (bool)a.IsChecked;
                axes[1] = (bool)b.IsChecked;
                axes[2] = (bool)c.IsChecked;
                if (!SETPLOT)
                {
                    SETPLOT = true;
               }
                modecontrol();
                if (COMMAND)
                { }
                else if (VACT)
                {
                    q = (++q) % CH;
                   // q = 0;//t
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x4;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0 + ADRANA + q * SAMPA);
                    Modbus.ReqStruc.quantity.w = (ushort)(SAMPA);
                   
                }
                else
                if(ADT)
                {
                    ADT = false;
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x4;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0);
                    Modbus.ReqStruc.quantity.w = 14;
                }
                else
                {
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x4;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0 + ADRANA + CH * SAMPA);
                    Modbus.ReqStruc.quantity.w = 2*SAMPS*CH;
                }
                //    Modbus.Require(1, 0x4, (ushort)(Modbus.INPADR0 + ADRANA + 4 * SAMPA), 120);
                if (!WAIT)
                {
                    WAIT = true;
                    Modbus.Require(Modbus.ReqStruc);
                    Errors.Text = nreq.ToString() + " " + nresp.ToString() + " " + nana.ToString()+"\n"+errstr;
                    nreq++;
                }

            }
            catch (Exception e)
            {
                System.Windows.MessageBox.Show("Timer tick except:\n" + e.ToString());

            }
        }

        public void modecontrol()
        {
            if ( VACT && !VOLT)
            {
                VOLT = VACT;
                nreq = nresp = nana = 0;
                MyModel.Title = "Amplified Receiver voltages[ADC bits]";
                MyModel.Axes.Clear();
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Minimum = 0, Maximum = SAMPA * KATIM, AbsoluteMinimum = 0, AbsoluteMaximum = SAMPA * KATIM }); ;
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Minimum = -MAXANA, Maximum = MAXANA, AbsoluteMinimum = -MAXANA, AbsoluteMaximum = MAXANA });
                MyModel.Series.Clear();
                this.MyModel.Series.Add(sg);
                for (i = 0; i < CH ; i++)
                    this.MyModel.Series.Add(sa[i]);             
             }
            else if (!VACT && VOLT)
            {
                nreq = nresp = nana = 0;
                VOLT = VACT;
               // SW = false;
                MyModel.Title = "Wind speed[m/s]";
                MyModel.Axes.Remove(MyModel.Axes[1]);
                MyModel.Axes.Remove(MyModel.Axes[0]);
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Minimum = 0, Maximum = (double)HR / 100, AbsoluteMinimum = 0, AbsoluteMaximum = (double)HR / 100 });
                MyModel.Axes.Add(new LinearAxis { Position = AxisPosition.Left, Minimum = -MAXVEL, Maximum = MAXVEL, AbsoluteMinimum = -ABSMAXVEL, AbsoluteMaximum = ABSMAXVEL });
                MyModel.Series.Clear();
                this.MyModel.Series.Add(sf);                
                for (i = 0; i < CH; i++)
                    this.MyModel.Series.Add(s[i]);

            }
        }


        public void CreatePolyline()
        {
            double con;
           
            k = ADRANA + q*SAMPA;
            for (int i = q * SAMPANA; i < (q + 1) * SAMPANA; i++)
            { 
                for (int j = 0; j < CH; j++)
                {
                    A[i, j] = (short) Modbus.INPREGS[k].w;
                    k++;
                }
                // q = (++q) % CH;


                //      if ((bool)Ustop.IsChecked)
                /*

                //          for (int i = 0; i < SAMPA; i++)

                  //       {

                          if ((bool)X.IsChecked)
                          //if(GX)
                          {
                              sa[0].Points.Add(new DataPoint(i * con, A[i, 0]));

                              sa[1].Points.Add(new DataPoint(i * con, A[i, 1]));
                          }
                          if ((bool)Y.IsChecked)
                      //    if(GY)
                          {

                              sa[2].Points.Add(new DataPoint(i * con, A[i, 2]));

                              sa[3].Points.Add(new DataPoint(i * con, A[i, 3]));
                          }
                  */
            }
            //     this.MyModel.InvalidatePlot(true);
            //}

            if (q == (CH-1))
            {
                if (GU)
                    con = KATIM * 6;
                else
                    con = KATIM;
                nana++;
                for(int ij=0;ij<CH;ij++)
                    sa[ij].Points.Clear();                
                for (int i = 0; i < SAMPA; i++)
                {
                    for (int ij = 0; ij < CH; ij++)
                        if (axes[ij])
                         sa[ij].Points.Add(new DataPoint(i * con, A[i, ij]));
                }
                sg.Points.Add(new DataPoint(0, 0));//t
                sg.Points.Add(new DataPoint(SAMPA * KATIM, 0));//t
                this.MyModel.InvalidatePlot(true);
            }
        }
  
         public void CreatePolySpeed()
        {
            double absol,fi,dfi;
            if (j >= HR)
            {
                j = 0;
                for (i = 0; i <  (CH);i++)
                {
                    s[i].Points.Clear();
                }
            }
            k = 0;
            for (int i = 0; i <  SAMPS; i++)
            {                
                  {
                    //  if ((bool)(V.IsChecked))
                    //                 if (VACT)
                    if (!GWM)
                    {
                        for (int ijk = 0; ijk < CH; ijk++)
                        {
                            F[i, ijk] = Modbus.ConvRegsToFloat(Modbus.INPREGS, ADRANA + CH * SAMPA + 2 * (CH * i + ijk));
                            if (axes[ijk])
                                s[ijk].Points.Add(new DataPoint(0.01 * j, F[i, ijk]));
                            /*
                            F[i, 1] = Modbus.ConvRegsToFloat(Modbus.INPREGS, ADRANA + CH * SAMPA + 2 * (k + 1));
                            s[1].Points.Add(new DataPoint(0.01 * j, F[i, 1]));//t
                            F[i, 2] = Modbus.ConvRegsToFloat(Modbus.INPREGS, 420 + 2 * (k));
                            if ((bool)total.IsChecked)
                            {
                                
                                
                            }
                            if ((bool)dif.IsChecked)
                            {
                                F[i, CH] = F[i, 0] - F[i, 1];
                                s[CH].Points.Add(new DataPoint(0.01 * j, F[i, CH]));//t
                            }
                            sum[0] += F[i, 0];
                            sum[1] += F[i, 1];                      
                        }
                        k++;
                        k++;
                        if ((bool)b.IsChecked)
                        {
                     
                            F[i, 3] = Modbus.ConvRegsToFloat(Modbus.INPREGS, 420 + 2 * (k+1));
                            if ((bool)total.IsChecked)
                            {
                                s[2].Points.Add(new DataPoint(0.01 * j, F[i, 2]));//t                 
                                s[3].Points.Add(new DataPoint(0.01 * j, F[i, 3]));//t
                            }
                           
                            if ((bool)dif.IsChecked)
                            {
                                F[i, CH + 1] = F[i, 2] - F[i, 3];
                                 s[CH + 1].Points.Add(new DataPoint(0.01 * j, F[i, CH + 1]));//t
                            }
                            sum[2] += F[i, 2];
                            sum[3] += F[i, 3];
                        }
                        k++;
                        k++;
                            */
                            /*
                                                        //  if ((bool)X.IsChecked)
                                                        if (GX)
                                                        {

                                                            s[0].Points.Add(new DataPoint(0.01 * j, F[i, 0]));
                                                            sum0 += F[i, 0];
                                                        }
                                                        //  if ((bool)Y.IsChecked)
                                                        if (GY)
                                                        {

                                                            s[1].Points.Add(new DataPoint(0.01 * j, F[i, 1]));
                                                            sum1 += F[i, 1];
                                                        }

                                                    }
                            */
                        }
                    }
                    else
                       //         if ((bool)VM.IsChecked)
                       if (GWM)
                    {
                        //   if ((bool)X.IsChecked)
                        if (GX)
                        {
                            absol = Abs(F[i, 0], F[i, 1]);
                            s[0].Points.Add(new DataPoint(0.01 * j, absol));
                            sum0 += absol;
                        }
                        //    if ((bool)Y.IsChecked)
                        if (GY)
                        {
                            fi = (180 / Math.PI) * Math.Atan2(F[i, 1], F[i, 0]);
                            dfi = fi - fimi;

                            if (dfi < -180)
                                fi += 360;
                            else if (dfi > 180)
                                fi -= 360;
                            fimi = fi;
                            s[1].Points.Add(new DataPoint(0.01 * j, 0.1 * fi));
                            sum1 += fi;
                        }

                    }
                }
                j++;
                if (j >= HR)
                {
                    ADT = true;
                }
            }
 
            this.MyModel.InvalidatePlot(true);
/*
            o++;
            if (o >= NR)
            {
                o = 0;
                s[0].Points.Clear();
                s[1].Points.Clear();
                fimi = 0;
            }
*/
        }       

    }


}