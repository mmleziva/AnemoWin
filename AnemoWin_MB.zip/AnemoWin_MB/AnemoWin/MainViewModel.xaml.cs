﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OxyPlot;
using OxyPlot.Series;


namespace AnemoWin
{
    /// <summary>
    /// Interakční logika pro MainViewModel.xaml
    /// </summary>
    public partial class MainViewModel : Window
    {
        public MainViewModel()
        {
            InitializeComponent();
            this.MyModel = new PlotModel { Title = "Example 1" };
            this.MyModel.Series.Add(new FunctionSeries(Math.Cos, 0, 10, 0.1, "cos(x)"));
            LineSeries s1 = new LineSeries()
            {
                Title = "Vx"

            };
            //s1.Points = LP;
            s1.Points.Add(new DataPoint(0.8, 1.1));
            s1.Points.Add(new DataPoint(1, 4));
            s1.Points.Add(new DataPoint(4, 2));
            s1.Points.Add(new DataPoint(6.9, 3.09));
            this.MyModel.Series.Add(s1);

        }
        public PlotModel MyModel { get; private set; }
    }
}
