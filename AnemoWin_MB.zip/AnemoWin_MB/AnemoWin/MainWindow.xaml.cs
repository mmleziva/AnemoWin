﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Windows.Threading;
using System.IO;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.Axes;
using OxyPlot.Wpf;
using MB;


namespace AnemoWin
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>


    public partial class MainWindow : Window
    {
        public static int l, m;
        public static string[] ports;
        public static string austr;
        public static List<string> portsList;
        public delegate void err(string er, Exception e);
        public static byte[] wb = new byte[2];
        public static byte[] fb = new byte[4];
        public static double[] sum = new double[CH];
        public static Single[] fa = new Single[CH];
        public static Single[] Rec = new Single[CH];//t
        public static bool SAVING = false, SHOWING = false;//t
        public static BinaryWriter bw;
        public static BinaryReader br;
        public Single R, Q;
        public static System.IO.FileStream ftemp;
        public static int js,nerr;
        public static event err Err;
        public static double Cfil, Cmul;
        public static Single dl0, dl1, dl2, dl3;
        public static Single amp0, amp1, amp2, amp3, temper;
        public string filename;
        string delastr;
        public static UInt16 ADRANA = 20;
        public bool COMMAND;
        Modbus mbus;
        public static string errstr;

        public MainWindow()
        {
            InitializeComponent();
            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;
            this.DataContext = this;


            mbus = new Modbus();
            Graph();
            Modbus.MBrec += new Modbus.rec(RewP);
            if (ser.serial.IsOpen)
                COM.Background = Brushes.LightGreen;
            else
                COM.Background = Brushes.Pink;
            COM.Content = MB.ser.serial.PortName;
        }

        public void comb(ushort c)
        {
            Modbus.HOLDREGS[0].L = (byte)c;
            Modbus.ReqStruc.unitId = 0x1;
            Modbus.ReqStruc.funCode = 0x10;
            Modbus.ReqStruc.startAdr.w = Modbus.HOLDADR0;
            Modbus.ReqStruc.quantity.w = 1;
            COMMAND = true;
        }
        
        private void annul_Click(object sender, RoutedEventArgs e)
        {
            comb('d');
            annul.Background = Brushes.LimeGreen;
            nul.Background = Brushes.LightGray;
           // Correct.Background = Brushes.LightGray;
            D0.Text = "0.000";
            D1.Text = "0.000";
            D2.Text = "0.000";
            /*
            filter.Content = "1";
            Cfil = 1;
            Cfilter.Value = 0;
            Cmul = 28;
            Multi.Content = "28" + "mm";
            */
        }

        private void GD_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Modbus.ReqStruc.unitId = 0x1;
            Modbus.ReqStruc.funCode = 0x4;
            Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0 + ADRANA);
            Modbus.ReqStruc.quantity.w = 4;
            COMMAND = true;
          //  Modbus.Require(1, 0x4, (ushort)(Modbus.INPADR0 + ADRANA), (ushort)(SAMPA));
           
        }

        private void nul_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            comb('n');
         
            CLICK = true;
        }

        private void nul_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (CLICK)
            {
                Modbus.ReqStruc.unitId = 0x1;
                Modbus.ReqStruc.funCode = 0x3;
                // Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0+2);
                Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 6);
                //  Modbus.ReqStruc.quantity.w = 20;
                Modbus.ReqStruc.quantity.w = CH*2;
                COMMAND = true;
                annul.Background = Brushes.LightGray;
              //  Correct.Background = Brushes.LightGray;
             //   nul.Background = Brushes.LimeGreen;
               
            }

        }       

        /*
        private void Imgexport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Configure save file dialog box
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Shot"; // Default file name
                dlg.Filter = " documents(png)|*.png|documents(pdf)|*.pdf|svg documents(svg)| *.svg "; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    if (dlg.FilterIndex==2)
                    {
                        using (var fs = File.Create(dlg.FileName + dlg.DefaultExt))
                        {
                           // var pdfexp = new graph.PdfExporter { Width = 800, Height = 400 };
                           // pdfexp.Export(graph.MyModel, fs);
                        }

                    }
                    else
                        // Save document               
                    using (var fs = new System.IO.FileStream(dlg.FileName + dlg.DefaultExt, FileMode.OpenOrCreate))
                    {
                        switch (dlg.FilterIndex)
                        {
                           case 1:
                                    var pngexp = new OxyPlot.PngEncoderOptions();// PngExporter();
                            //    pngexp.Export(graph.MyModel, fs);
                                break;
                           case 3:
                                var svgexp = new OxyPlot.SvgExporter();
                                    //  svgexp.Export(graph.MyModel, fs);
                                    svgexp.Export(MyModel, fs);
                                    break;
                           default:
                                    break;
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Save file except:\n" + ex.ToString());
            }
        }
*/
        private void Imgexport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Configure save file dialog box
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Shot"; // Default file name
                dlg.Filter = " documents(png)|*.png|documents(pdf)|*.pdf|svg documents(svg)| *.svg "; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    if (dlg.FilterIndex == 2)
                    {
                        using (var fs = File.Create(dlg.FileName + dlg.DefaultExt))
                        {
                            var pdfExporter = new OxyPlot.PdfExporter { Width = 600, Height = 400 };
                            pdfExporter.Export(MyModel, fs);
                        }

                    }
                    else
                        // Save document               
                        using (var fs = new System.IO.FileStream(dlg.FileName + dlg.DefaultExt, FileMode.OpenOrCreate))
                        {
                            switch (dlg.FilterIndex)
                            {
                                case 1:
                                    var pngexp = new PngExporter();

                                    pngexp.Export(MyModel, fs);
                                    break;
                                case 3:
                                    var svgexp = new OxyPlot.SvgExporter();
                                    svgexp.Export(MyModel, fs);
                                    break;
                                default:
                                    break;
                            }
                        }
                }

            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Save file except:\n" + ex.ToString());
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)TEMPBLOCK.IsChecked)
            {
                comb('b');
                //   Modbus.HOLDREGS[0].L = (byte)'b';
            }
            else
            {
                comb('a');
                //   Modbus.HOLDREGS[0].L = (byte)'a';
            }
          //  Modbus.Require(1, 0x10, Modbus.HOLDADR0, 1);
        }

        private void Cfilter_LostMouseCapture(object sender, MouseEventArgs e)
        {
            if (ser.BOPEN)
            {
                
                Modbus.ConvFloatToRegs((Single)Cfil, Modbus.HOLDREGS, 4);
                Modbus.ReqStruc.unitId = 0x1;
                Modbus.ReqStruc.funCode = 0x10;
                Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 4);
                Modbus.ReqStruc.quantity.w = 2;
                COMMAND = true;
                Cfilter.Background = Brushes.LimeGreen;
            }
        }

        private void Cfilter_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Cfil = Math.Pow(10, -Cfilter.Value);    
            filter.Content = Cfil.ToString("0.000");
            Cfilter.Background = Brushes.White;
        }

        private void Ustop_Checked(object sender, RoutedEventArgs e)
        {
            GU = (bool)Ustop.IsChecked;
        }

        private void Delay_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

                delastr = Convert.ToInt16(Delay.Value).ToString();
                Labelay.Content = delastr;                
                Delay.Background = Brushes.White;
  
        }

        private void Savet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (SAVING)
                    Savet.Background = Brushes.Red;
                else
                {

                    Savet.Background = Brushes.LightGray;
                    // Configure save file dialog box
                    var dlg = new Microsoft.Win32.SaveFileDialog();
                    dlg.FileName = "Plotemp"; // Default file name
                    dlg.Filter = " binary(bin)|*.bin"; // Filter files by extension

                    // Show save file dialog box
                    Nullable<bool> result = dlg.ShowDialog();

                    // Process save file dialog box results
                    if (result == true)
                    {
                      //  js = 0;
                        SAVING = true;
                        filename = dlg.FileName + dlg.DefaultExt;
                        ftemp = new System.IO.FileStream(filename, FileMode.Create);
                        bw = new BinaryWriter(ftemp);
                    }
                }
            }
            catch (Exception ex)
            {
                    System.Windows.MessageBox.Show("Save file except:\n" + ex.ToString());
            }

         }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            /*
            double fi=0, dfi=0;
            try
            {
                if (SAVING && !SHOWING)
                {
                    SAVING = false;
                    ftemp.Dispose();
                    ftemp = new System.IO.FileStream(filename, FileMode.Open);
                    br = new BinaryReader(ftemp);
                    SHOWING = true;
                }
                else if (!SHOWING)
                {
                    var dlg = new Microsoft.Win32.OpenFileDialog();
                    dlg.FileName = "Plotemp"; // Default file name
                    dlg.Filter = " binary(bin)|*.bin"; // Filter files by extension

                    // Show save file dialog box
                    Nullable<bool> result = dlg.ShowDialog();

                    // Process save file dialog box results
                    if (result == true)
                    {
                        filename = dlg.FileName + dlg.DefaultExt;
                        ftemp = new System.IO.FileStream(filename, FileMode.Open);
                        br = new BinaryReader(ftemp);
                        SHOWING = true;
                    }
                    else SHOWING = false;
                }
                if (SHOWING)
                {
                    for(i=0; i < CH; i++)
                    {
                        s[i].Points.Clear();
                    }
                    long MAXL = ftemp.Length / sizeof(Single);
                    try
                    {
                        for (l = 0; l < MAXL / 2; l++)
                        {
                            for(i=0;i<CH; i++)
                            {
                                Rec[i]= br.ReadSingle();
                            }
                            if (!(bool)VM.IsChecked)
                            {
                                if ((bool)a.IsChecked)
                                {
                                    if ((bool)total.IsChecked)
                                    {
                                        s[0].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[0]));
                                        s[1].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[1]));
                                    }
                                    if ((bool)dif.IsChecked)
                                    {
                                        s[4].Points.Add(new OxyPlot.DataPoint(0.25 * l, (Rec[0] - Rec[1])));
                                        
                                    }
                                }
                                if ((bool)b.IsChecked)
                                {
                                    if ((bool)total.IsChecked)
                                    {
                                        s[2].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[2]));
                                        s[3].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[3]));
                                    }
                                    if ((bool)dif.IsChecked)
                                    {
                                        s[5].Points.Add(new OxyPlot.DataPoint(0.25 * l, (Rec[2] - Rec[3])));

                                    }
                                }
                            }
                            else
                            {
                                if ((bool)a.IsChecked)
                                {
                                    // s[0].Points.Add(new DataPoint(0.01 * l, Abs(R, Q)));
                                    s[0].Points.Add(new OxyPlot.DataPoint(0.25 * l,Abs(R, Q)));
                                }
                                if ((bool)b.IsChecked)
                                {
                                    fi = (180 / Math.PI) * Math.Atan2(Q, R);
                                    dfi = fi - fimi;

                                    if (dfi < -180)
                                        fi += 360;
                                    else if (dfi > 180)
                                        fi -= 360;
                                    fimi = fi;
                                    s[1].Points.Add(new OxyPlot.DataPoint(0.01 * l, 0.1 * fi));
                                }
                            }
                        }
                    }
                    catch (EndOfStreamException ex)
                    {
                        Showt.Background = Brushes.Orange;
                    }
                    finally
                    {
                      MyModel.InvalidatePlot(true);
                        ftemp.Dispose();
                        SHOWING = false;
                    }
                }

            }
            catch (Exception ec)
            { }
                        */
        }


        private void Delay_LostMouseCapture(object sender, MouseEventArgs e)
        {
            if (ser.BOPEN)
            {
                 Delay.Background = Brushes.LimeGreen;
            }
        }
    
        private void Cmulti_LostMouseCapture(object sender, MouseEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    Modbus.ConvFloatToRegs((Single)Cmul, Modbus.HOLDREGS, 2);
                    Modbus.ConvFloatToRegs((Single)Cfil, Modbus.HOLDREGS, 4);
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x10;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 2);
                    Modbus.ReqStruc.quantity.w = 2;
                    COMMAND = true;
                    Cmulti.Background = Brushes.LimeGreen;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void Cmulti_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Multi != null)
            {
                 Cmul = Cmulti.Value;
                austr = Cmul.ToString("0.000");
                if (Multi != null) Multi.Content = austr + "mm";
            }
            Cmulti.Background = Brushes.White;
        }

        private void STOPPED_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               STOP = (bool)STOPPED.IsChecked;
                 if (STOP)
                {
                    MyModel.Axes[0].AbsoluteMaximum = HR * 5;
                    MyModel.Axes[0].Maximum = HR * 0.2;
                    MyModel.Axes[0].Minimum = 0;
                    U.IsEnabled = false;  //t
                    if ((bool)V.IsChecked || (bool)VM.IsChecked)
                    {
                        //                     Savet.IsEnabled = true;   //t
                        Showt.IsEnabled = true;
                    }
                }
                else
                {
 
                   MyModel.Axes[0].Maximum = HR / 100;
                   MyModel.Axes[0].AbsoluteMaximum = HR / 100;
                  MyModel.Axes[0].Minimum = 0;
                   MyModel.Axes.Remove(MyModel.Axes[0]);
                   MyModel.Axes.Add(new OxyPlot.Axes.LinearAxis { Position = 0, Minimum = 0, Maximum = HR / 100, AbsoluteMinimum = 0, AbsoluteMaximum = (double)HR / 100 });
                    Showt.Background = Brushes.LightGray;
                    Showt.IsEnabled = false;
                    U.IsEnabled = true;   //t
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
            finally
            {
                this.MyModel.InvalidatePlot(true);
            }
        }

        private void VM_Checked(object sender, RoutedEventArgs e)
        {
        //   GWM = (bool)VM.IsChecked;
            s[0].Title = "Vabs";
           s[1].Title = "A[°/10]";
            U.IsEnabled = false;
            VM.IsEnabled = true;
        }
 
        private void V_Checked(object sender, RoutedEventArgs e)
        {         
            if (ser.BOPEN)
            {
                VACT = false;
                comb('v');
                s[0].Title = "Vx";
                s[1].Title = "Vy";
                Cmulti.IsEnabled = true;
                Cfilter.IsEnabled = true;
                nul.IsEnabled = true;
                annul.IsEnabled = true;
              //  Correct.IsEnabled = true;
                U.IsEnabled = true;
                VM.IsEnabled = true;
                Ustop.IsEnabled = false;
                Delay.IsEnabled = false;
                ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, SAMPS*10);//  20 samples by 10ms =200ms interval
                a.Content = "bc";
                b.Content = "ca";
                c.Content = "ab";
            }
        }

        public void U_Checked(object sender, RoutedEventArgs e)
        {
            if (ser.BOPEN)
            {
                GU = false; //test
                STOPPED.IsEnabled = true;
                VACT = true;
                comb('u');
                Cmulti.IsEnabled = false;
                Cfilter.IsEnabled = false;
                nul.IsEnabled = false;
                annul.IsEnabled =false;
           //     Correct.IsEnabled = false;
                V.IsEnabled = true;
                VM.IsEnabled = false;
                Ustop.IsEnabled = true;
                Ustop.Content = "Uoff:on";
                Delay.IsEnabled = true;
                Ustop.Background = Brushes.LightGray;
                ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, 200);//  200ms interval
                MyModel.Axes[0].AbsoluteMaximum =SAMPA *KATIM;
               MyModel.Axes[0].Maximum = SAMPA * KATIM;
                a.Content = "a";
                b.Content = "b";
                c.Content = "c";
            }
        }

        private void Ustop_Click(object sender, RoutedEventArgs e)
        {
            /*
            if (ser.BOPEN)
            {
                STOPPED.IsEnabled = false;
                MyModel.Axes[0].AbsoluteMaximum = SAMPA * KATIM * 6;
                MyModel.Axes[0].Maximum = SAMPA * KATIM * 6;
                VACT = true;
                comb('s');
                Cmulti.IsEnabled = false;
                Cfilter.IsEnabled = false;
                nul.IsEnabled = false;
                annul.IsEnabled = false;
                V.IsEnabled = false;
                VM.IsEnabled = false;
                U.IsChecked = false;            

            }
               */
        }

        //delegate of received modbus frame
        public void RewP()
        {
            //nresp++;

            WAIT = false;
            byte fce = Modbus.rs.funCode;
            ushort r = Modbus.rs.words;
            ushort adrst = (ushort)(Modbus.rs.startAdr.w - Modbus.INPADR0);
            if(B.CRCERR)
            {
                nerr++;
                errstr = DateTime.Now.ToLongTimeString() + "  No:" + nerr.ToString() + "\n";
                errstr += "Modbus error:\n Bad receiving";
            }
            else
                switch (fce)
                {
                    case 3:
                        Cmul = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 2);
                        Cmulti.Value = Cmul;
                        austr = Cmul.ToString("0.000");
                        if (Multi != null) Multi.Content = austr + "mm";
                        Cfil = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 4);
                        filter.Content = Cfil.ToString("0.000");
                        if (Cfil > 0) Cfilter.Value = -Math.Log10(Cfil);
                    Cfilter.Background = Brushes.White;
                    dl0 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 6);
                    D0.Text =dl0.ToString();
                    dl1 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 8);
                    D1.Text = dl1.ToString();
                    dl2 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 10);
                    D2.Text = dl2.ToString();
                    nresp++;//t
                        if (CLICK)
                        {
                            CLICK = false;
                            nul.Background = Brushes.Lime;
                        }
                        break;

                case 4:
                    {
                        if (adrst < ADRANA)
                        {
                            temper = Modbus.ConvRegsToFloat(Modbus.INPREGS, 2);
                            T.Text = temper.ToString("0.00") + "°C";
                            amp0 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 6);
                            A0.Text = amp0.ToString();
                            amp1 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 8);
                            A1.Text = amp1.ToString();
                            amp2 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 10);
                            A2.Text = amp2.ToString();
                            
                        }
                        else if (adrst < (ADRANA + CH * SAMPA))
                        {
                            CreatePolyline();
                        }
                        else
                            CreatePolySpeed();
                            nresp++;//t
                        }
                    break;
                case 0x10:
                        if (CLICK)
                        {
                            nul.Background = Brushes.Green;
                        }
                        nresp++;//t
                        break;
                default:
                    {
                        
                        nerr++;
                        errstr= DateTime.Now.ToLongTimeString() + "  No:" + nerr.ToString() + "\n";
                        if (fce >= 0x80)
                        {
                           errstr += "Modbus error:\n Function " + (fce & 0x7f).ToString() + " return error no.:" + Modbus.RespStruc.errorCode.ToString();
                        }
                        else
                            errstr += "Modbus error:\n unknown function code received";
                    }
                    break;
                  
            }
            COMMAND = false;


        }

        public void vals()
        {
            Velx = sum[2] / (Math.Sqrt(3) * SAMPS);
            Vely = (sum[0] - sum[1]) / (3 * SAMPS);
            if ((bool)V.IsChecked)
            {
                
                string str0 = Velx.ToString("000.00");
                string str1 = Vely.ToString("000.00");
                Vx.Content = "Vx=" + str0 + "m/s";
                Vy.Content = "Vy=" + str1 + "m/s";
            }
            else if ((bool)(VM.IsChecked))
            {
                double Absol = Abs(Velx, Vely);

               double  fi = (180 / Math.PI) * Math.Atan2(Velx, Vely);
                /*
                dfi = fi - fimi;

                if (dfi < -180)
                    fi += 360;
                else if (dfi > 180)
                    fi -= 360;
                fimi = fi;
                */
                string str0 = Absol.ToString("000.00");
                string str1 = fi.ToString("000.00");
                Vx.Content = "Vm=" + str0 + "m/s";
                Vy.Content = "angle=" + str1 + "°";
            }
            else
            {
                Vx.Content = "";
                Vy.Content = "";
            }
            for (int iu = 0; iu < CH; iu++)
                sum[iu] = 0;
        }


    }


}
