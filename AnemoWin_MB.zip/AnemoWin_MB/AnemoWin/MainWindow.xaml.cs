﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Windows.Threading;
using System.IO;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.Axes;
using OxyPlot.Wpf;
using MB;


namespace AnemoWin
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>


    public partial class MainWindow : Window
    {
        static int[] bauds = { 9600, 19200, 38400, 76800, 115200, 230400, 460800 };
        //  public static bool CLICK = false;
        public static int l, m;
        public static string[] ports;
        public static string austr;
        public static List<string> portsList;
        public delegate void err(string er, Exception e);
        public static byte[] wb = new byte[2];
        public static byte[] fb = new byte[4];
        public static double[] sum = new double[CH];
        public static Single[] fa = new Single[CH];
        public static Single[] Rec = new Single[CH];//t
        public static bool SAVING = false, SHOWING = false;//t
        public static BinaryWriter bw;
        public static BinaryReader br;
        public Single R, Q;
        public static System.IO.FileStream ftemp;
        public static int js,nerr;
        public static event err Err;
        public static double Cfil, Cmul;
        public static Single dl0, dl1, dl2, dl3;
        public static Single amp0, amp1, amp2, amp3, temper;
        public string filename;
        string delastr;
        public static UInt16 ADRANA = 20;
        public bool COMMAND;
        Modbus mbus;
        public static string errstr;

        public MainWindow()
        {
            InitializeComponent();
            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;
            this.DataContext = this;


            mbus = new Modbus();
            Graph();
            Modbus.MBrec += new Modbus.rec(RewP);
        }

        public void comb(ushort c)
        {
            Modbus.HOLDREGS[0].L = (byte)c;
            Modbus.ReqStruc.unitId = 0x1;
            Modbus.ReqStruc.funCode = 0x10;
            Modbus.ReqStruc.startAdr.w = Modbus.HOLDADR0;
            Modbus.ReqStruc.quantity.w = 1;
            COMMAND = true;
        }
        
        private void annul_Click(object sender, RoutedEventArgs e)
        {
            comb('d');
            annul.Background = Brushes.LimeGreen;
            nul.Background = Brushes.LightGray;
            Correct.Background = Brushes.LightGray;
            D0.Text = "32.000";
            D1.Text = "32.000";
            D2.Text = "32.000";
            D3.Text = "32.000";
            filter.Content = "1";
            Cfil = 1;
            Cfilter.Value = 0;
            Cmul = 28;
            Multi.Content = "28" + "mm";

        }

        private void GD_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Modbus.ReqStruc.unitId = 0x1;
            Modbus.ReqStruc.funCode = 0x4;
            Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0 + ADRANA);
            Modbus.ReqStruc.quantity.w = 4;
            COMMAND = true;
          //  Modbus.Require(1, 0x4, (ushort)(Modbus.INPADR0 + ADRANA), (ushort)(SAMPA));
           
        }

        private void nul_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            comb('n');
            //Modbus.Require(1, 0x10, Modbus.HOLDADR0, 1);

            // SELFT = true;
            CLICK = true;
        }

        private void nul_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (CLICK)
            {
                Modbus.ReqStruc.unitId = 0x1;
                Modbus.ReqStruc.funCode = 0x3;
                Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0+2);
                Modbus.ReqStruc.quantity.w = 20;
                COMMAND = true;
                // Modbus.Require(1, 0x3, (ushort)(Modbus.HOLDADR0 + 2), 20);
                annul.Background = Brushes.LightGray;
                Correct.Background = Brushes.LightGray;
                nul.Background = Brushes.LimeGreen;
               
            }

        }       

        private void Correct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                annul.Background = Brushes.LightGray;
                Correct.Background = Brushes.LimeGreen;
                nul.Background = Brushes.LightGray;
                if (ser.BOPEN)
                {
                    // Modbus.HOLDREGS[0].L = (byte)'d';
                    Modbus.ConvFloatToRegs(dl0, Modbus.HOLDREGS, 6);
                    Modbus.ConvFloatToRegs(dl1, Modbus.HOLDREGS, 8);
                    Modbus.ConvFloatToRegs(dl2, Modbus.HOLDREGS, 10);
                    Modbus.ConvFloatToRegs(dl3, Modbus.HOLDREGS, 12);
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x10;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 6);
                    Modbus.ReqStruc.quantity.w = 8;
                    COMMAND = true;
                   // Modbus.Require(1, 0x10, (ushort)(Modbus.HOLDADR0 + 6), 8);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Modbus.ReqStruc.unitId = 0x1;
            Modbus.ReqStruc.funCode = 0x4;
            Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.INPADR0);
            Modbus.ReqStruc.quantity.w = 14;
            COMMAND = true;
        //    Modbus.Require(1, 0x4, Modbus.INPADR0, 14);
        }

        private void Imgexport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Configure save file dialog box
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Shot"; // Default file name
                dlg.Filter = " documents(png)|*.png|documents(pdf)|*.pdf|svg documents(svg)| *.svg "; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    if (dlg.FilterIndex==2)
                    {
                        using (var fs = File.Create(dlg.FileName + dlg.DefaultExt))
                        {
                           // var pdfexp = new graph.PdfExporter { Width = 800, Height = 400 };
                           // pdfexp.Export(graph.MyModel, fs);
                        }

                    }
                    else
                        // Save document               
                    using (var fs = new System.IO.FileStream(dlg.FileName + dlg.DefaultExt, FileMode.OpenOrCreate))
                    {
                        switch (dlg.FilterIndex)
                        {
                           case 1:
                                    var pngexp = new OxyPlot.PngEncoderOptions();// PngExporter();
                            //    pngexp.Export(graph.MyModel, fs);
                                break;
                           case 3:
                                var svgexp = new OxyPlot.SvgExporter();
                                    //  svgexp.Export(graph.MyModel, fs);
                                    svgexp.Export(MyModel, fs);
                                    break;
                           default:
                                    break;
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Save file except:\n" + ex.ToString());
            }
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)TEMPBLOCK.IsChecked)
            {
                comb('b');
                //   Modbus.HOLDREGS[0].L = (byte)'b';
            }
            else
            {
                comb('a');
                //   Modbus.HOLDREGS[0].L = (byte)'a';
            }
          //  Modbus.Require(1, 0x10, Modbus.HOLDADR0, 1);
        }

        private void Cfilter_LostMouseCapture(object sender, MouseEventArgs e)
        {
            if (ser.BOPEN)
            {
                
                Modbus.ConvFloatToRegs((Single)Cfil, Modbus.HOLDREGS, 4);
                Modbus.ReqStruc.unitId = 0x1;
                Modbus.ReqStruc.funCode = 0x10;
                Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 4);
                Modbus.ReqStruc.quantity.w = 2;
                COMMAND = true;
                //  Modbus.Require(1, 0x10, (ushort)(Modbus.HOLDADR0 + 4), 2);
                Cfilter.Background = Brushes.LimeGreen;
            }
        }

        private void Cfilter_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Cfil = Math.Pow(10, -Cfilter.Value);    
            filter.Content = Cfil.ToString("0.000");
            Cfilter.Background = Brushes.White;
        }

        private void Ustop_Checked(object sender, RoutedEventArgs e)
        {
            GU = (bool)Ustop.IsChecked;
        }

        private void Y_Checked(object sender, RoutedEventArgs e)
        {
           GY = (bool)Y.IsChecked;
        }

        private void X_Checked(object sender, RoutedEventArgs e)
        {
           GX = (bool)X.IsChecked;
        }

        private void Delay_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

                delastr = Convert.ToInt16(Delay.Value).ToString();
                Labelay.Content = delastr;                
                Delay.Background = Brushes.White;
  
        }

        private void comboBox_DropDownOpened(object sender, EventArgs e)
        {
            try
            {
              //  BOPEN = false;            //t
                ports = SerialPort.GetPortNames();
                Array.Resize(ref ports, ports.Length + 1);
                ports[ports.Length - 1] = "NONE";
                comboBox.ItemsSource = ports;
                
              
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

        }

        private void Savet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (SAVING)
                    Savet.Background = Brushes.Red;
                else
                {

                    Savet.Background = Brushes.LightGray;
                    // Configure save file dialog box
                    var dlg = new Microsoft.Win32.SaveFileDialog();
                    dlg.FileName = "Plotemp"; // Default file name
                    dlg.Filter = " binary(bin)|*.bin"; // Filter files by extension

                    // Show save file dialog box
                    Nullable<bool> result = dlg.ShowDialog();

                    // Process save file dialog box results
                    if (result == true)
                    {
                      //  js = 0;
                        SAVING = true;
                        filename = dlg.FileName + dlg.DefaultExt;
                        ftemp = new System.IO.FileStream(filename, FileMode.Create);
                        bw = new BinaryWriter(ftemp);
                    }
                }
            }
            catch (Exception ex)
            {
                    System.Windows.MessageBox.Show("Save file except:\n" + ex.ToString());
            }

         }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            double fi=0, dfi=0;
            try
            {
                if (SAVING && !SHOWING)
                {
                    SAVING = false;
                    ftemp.Dispose();
                    ftemp = new System.IO.FileStream(filename, FileMode.Open);
                    br = new BinaryReader(ftemp);
                    SHOWING = true;
                }
                else if (!SHOWING)
                {
                    var dlg = new Microsoft.Win32.OpenFileDialog();
                    dlg.FileName = "Plotemp"; // Default file name
                    dlg.Filter = " binary(bin)|*.bin"; // Filter files by extension

                    // Show save file dialog box
                    Nullable<bool> result = dlg.ShowDialog();

                    // Process save file dialog box results
                    if (result == true)
                    {
                        filename = dlg.FileName + dlg.DefaultExt;
                        ftemp = new System.IO.FileStream(filename, FileMode.Open);
                        br = new BinaryReader(ftemp);
                        SHOWING = true;
                    }
                    else SHOWING = false;
                }
                if (SHOWING)
                {
                    for(i=0; i < CH; i++)
                    {
                        s[i].Points.Clear();
                    }
                    long MAXL = ftemp.Length / sizeof(Single);
                    try
                    {
                        for (l = 0; l < MAXL / 2; l++)
                        {
                            for(i=0;i<CH; i++)
                            {
                                Rec[i]= br.ReadSingle();
                            }
                            if (!(bool)VM.IsChecked)
                            {
                                if ((bool)X.IsChecked)
                                {
                                    if ((bool)total.IsChecked)
                                    {
                                        s[0].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[0]));
                                        s[1].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[1]));
                                    }
                                    if ((bool)dif.IsChecked)
                                    {
                                        s[4].Points.Add(new OxyPlot.DataPoint(0.25 * l, (Rec[0] - Rec[1])));
                                        
                                    }
                                }
                                if ((bool)Y.IsChecked)
                                {
                                    if ((bool)total.IsChecked)
                                    {
                                        s[2].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[2]));
                                        s[3].Points.Add(new OxyPlot.DataPoint(0.25 * l, Rec[3]));
                                    }
                                    if ((bool)dif.IsChecked)
                                    {
                                        s[5].Points.Add(new OxyPlot.DataPoint(0.25 * l, (Rec[2] - Rec[3])));

                                    }
                                }
                            }
                            else
                            {
                                if ((bool)X.IsChecked)
                                {
                                    // s[0].Points.Add(new DataPoint(0.01 * l, Abs(R, Q)));
                                    s[0].Points.Add(new OxyPlot.DataPoint(0.25 * l,Abs(R, Q)));
                                }
                                if ((bool)Y.IsChecked)
                                {
                                    fi = (180 / Math.PI) * Math.Atan2(Q, R);
                                    dfi = fi - fimi;

                                    if (dfi < -180)
                                        fi += 360;
                                    else if (dfi > 180)
                                        fi -= 360;
                                    fimi = fi;
                                    s[1].Points.Add(new OxyPlot.DataPoint(0.01 * l, 0.1 * fi));
                                }
                            }
                        }
                    }
                    catch (EndOfStreamException ex)
                    {
                        Showt.Background = Brushes.Orange;
                    }
                    finally
                    {
                      MyModel.InvalidatePlot(true);
                        ftemp.Dispose();
                        SHOWING = false;
                    }
                }

            }
            catch (Exception ec)
            { }
    }

        private void Delay_LostMouseCapture(object sender, MouseEventArgs e)
        {
            if (ser.BOPEN)
            {
                 Delay.Background = Brushes.LimeGreen;
            }
        }
    
        private void Cmulti_LostMouseCapture(object sender, MouseEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    Modbus.ConvFloatToRegs((Single)Cmul, Modbus.HOLDREGS, 2);
                    Modbus.ConvFloatToRegs((Single)Cfil, Modbus.HOLDREGS, 4);
                    Modbus.ReqStruc.unitId = 0x1;
                    Modbus.ReqStruc.funCode = 0x10;
                    Modbus.ReqStruc.startAdr.w = (ushort)(Modbus.HOLDADR0 + 2);
                    Modbus.ReqStruc.quantity.w = 2;
                    COMMAND = true;
                    //  Modbus.Require(1, 0x10, (ushort)(Modbus.HOLDADR0 + 2), 2);
                    Cmulti.Background = Brushes.LimeGreen;
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        private void Cmulti_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Multi != null)
            {
                 Cmul = Cmulti.Value;
                austr = Cmul.ToString("0.000");
                if (Multi != null) Multi.Content = austr + "mm";
            }
            Cmulti.Background = Brushes.White;
        }

        private void STOPPED_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               STOP = (bool)STOPPED.IsChecked;
                 if (STOP)
                {
                    MyModel.Axes[0].AbsoluteMaximum = HR * 5;
                    MyModel.Axes[0].Maximum = HR * 0.2;
                    MyModel.Axes[0].Minimum = 0;
                    U.IsEnabled = false;  //t
                    if ((bool)V.IsChecked || (bool)VM.IsChecked)
                    {
                        //                     Savet.IsEnabled = true;   //t
                        Showt.IsEnabled = true;
                    }
                }
                else
                {
 
                   MyModel.Axes[0].Maximum = HR / 100;
                   MyModel.Axes[0].AbsoluteMaximum = HR / 100;
                  MyModel.Axes[0].Minimum = 0;
                   MyModel.Axes.Remove(MyModel.Axes[0]);
                   MyModel.Axes.Add(new OxyPlot.Axes.LinearAxis { Position = 0, Minimum = 0, Maximum = HR / 100, AbsoluteMinimum = 0, AbsoluteMaximum = (double)HR / 100 });
                    Showt.Background = Brushes.LightGray;
                    Showt.IsEnabled = false;
                    U.IsEnabled = true;   //t
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
            finally
            {
                this.MyModel.InvalidatePlot(true);
            }
        }

        private void VM_Checked(object sender, RoutedEventArgs e)
        {
           GWM = (bool)VM.IsChecked;
            s[0].Title = "Vabs";
           s[1].Title = "A[°/10]";
            U.IsEnabled = false;
            VM.IsEnabled = true;
        }
 
        private void V_Checked(object sender, RoutedEventArgs e)
        {         
            if (ser.BOPEN)
            {
                VACT = false;
                comb('v');
                s[0].Title = "Vx";
                s[1].Title = "Vy";
                Cmulti.IsEnabled = true;
                Cfilter.IsEnabled = true;
                nul.IsEnabled = true;
                annul.IsEnabled = true;
                Correct.IsEnabled = true;
                U.IsEnabled = true;
                VM.IsEnabled = true;
                Ustop.IsEnabled = false;
                Delay.IsEnabled = false;
                ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, 250);//  250ms interval
            }
        }

        public void U_Checked(object sender, RoutedEventArgs e)
        {
            if (ser.BOPEN)
            {
                STOPPED.IsEnabled = true;
                VACT = true;
                comb('u');
                Cmulti.IsEnabled = false;
                Cfilter.IsEnabled = false;
                nul.IsEnabled = false;
                annul.IsEnabled =false;
                Correct.IsEnabled = false;
                V.IsEnabled = true;
                VM.IsEnabled = false;
                Ustop.IsEnabled = true;
                Ustop.Content = "Uoff:on";
                Delay.IsEnabled = true;
                Ustop.Background = Brushes.LightGray;
                ScanTimer.Interval = new TimeSpan(0, 0, 0, 0, 50);//  50ms interval
                MyModel.Axes[0].AbsoluteMaximum =SAMPA *KATIM;
               MyModel.Axes[0].Maximum = SAMPA * KATIM;
            }
        }

        private void Ustop_Click(object sender, RoutedEventArgs e)
        {
            if (ser.BOPEN)
            {
                STOPPED.IsEnabled = false;
                MyModel.Axes[0].AbsoluteMaximum = SAMPA * KATIM * 6;
                MyModel.Axes[0].Maximum = SAMPA * KATIM * 6;
                VACT = true;
                comb('s');
                Cmulti.IsEnabled = false;
                Cfilter.IsEnabled = false;
                nul.IsEnabled = false;
                annul.IsEnabled = false;
                V.IsEnabled = false;
                VM.IsEnabled = false;
                U.IsChecked = false;
                if (Ustop.Background == Brushes.LightPink)
                {
                    Ustop.Background = Brushes.LightGray;
                    Ustop.Content = "Uon";
                }
                else
                {
                    Ustop.Background = Brushes.LightPink;
                    Ustop.Content = "Uoff";
                }

            }
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                //  if (ser.BOPEN && (comboBox.SelectionBoxItem != comboBox.SelectedItem))
                {
                    if ((comboBox.SelectionBoxItem != comboBox.SelectedItem))
                  //      if (serial.IsOpen)
                        {
                    //     serial.Close();
                        }
                    if (comboBox.SelectedItem.ToString() == "NONE")
                    {
                        comboBox.Background = Brushes.Green;
                        comboBox.Foreground = Brushes.DarkRed;
                    }
                    else
                    {
                 //       serial.PortName = (string)comboBox.SelectedItem;                       
   //                     Ser.OpenCOM();
                        comboBox.Background = Brushes.Green;
                        comboBox.Foreground = Brushes.DarkGreen;
                    }                    

                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

        }
       
        private void ComboRates_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            try
            {
                if (ser.BOPEN)
                {
      //              serial.BaudRate = bauds[ComboRates.SelectedIndex];
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }

        }

        private void Parities_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (ser.BOPEN)
                {
                    switch (ComboParities.SelectedIndex)
                    {
                        case 0:
            //                serial.StopBits = StopBits.One;
            //                serial.Parity = Parity.Odd;
                            break;
                        case 1:
           //                 serial.StopBits = StopBits.One;
           //                 serial.Parity = Parity.Even;
                            break;
                        case 2:
           //                 serial.StopBits = StopBits.Two;
           //                 serial.Parity = Parity.None;
                            break;
                        case 3:
           //                 serial.StopBits = StopBits.One;
           //                 serial.Parity = Parity.None;
                            break;

                        default:
                            break;

                    }

                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }


        }

        /*
        public static List<string> Getportnames()
        {
            portsList = new List<string>();
            foreach (string s in ports)
            {
                portsList.Add(s);
            }
            portsList.Add("NONE");
            return portsList;
        }

        */
        
        //delegate of received modbus frame
        public void RewP()
        {
            nresp++;

            WAIT = false;
            byte fce = Modbus.rs.funCode;
            ushort r = Modbus.rs.words;
            ushort adrst = (ushort)(Modbus.rs.startAdr.w - Modbus.INPADR0);
            if(B.CRCERR)
            {
                nerr++;
                errstr = DateTime.Now.ToLongTimeString() + "  No:" + nerr.ToString() + "\n";
                errstr += "Modbus error:\n Bad receiving";
            }
            else
            switch (fce)
            {
                case 3:                
                    Cmul = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 2);
                    Cmulti.Value = Cmul;
                    austr = Cmul.ToString("0.000");
                    if (Multi != null) Multi.Content = austr + "mm";
                    Cfil = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 4);                  
                    Cfil = Math.Pow(10, -Cfilter.Value);
                    filter.Content = Cfil.ToString("0.000");
                    Cfilter.Value = -Math.Log10(Cfil);
                    Cfilter.Background = Brushes.White;
                    dl0 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 6);
                    D0.Text =dl0.ToString();
                    dl1 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 8);
                    D1.Text = dl1.ToString();
                    dl2 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 10);
                    D2.Text = dl2.ToString();
                    dl3 = Modbus.ConvRegsToFloat(Modbus.HOLDREGS, 12);
                    D3.Text = dl3.ToString();
                    break;

                case 4:
                    {
                        if (adrst < ADRANA)
                        {
                            temper = Modbus.ConvRegsToFloat(Modbus.INPREGS, 2);
                            T.Text = temper.ToString("0.00") + "°C";
                            amp0 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 6);
                            A0.Text = amp0.ToString();
                            amp1 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 8);
                            A1.Text = amp1.ToString();
                            amp2 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 10);
                            A2.Text = amp2.ToString();
                            amp3 = Modbus.ConvRegsToFloat(Modbus.INPREGS, 12);
                            A3.Text = amp3.ToString();
                        }
                        else if (adrst < (ADRANA + CH * SAMPA))
                        {
                            CreatePolyline();
                        }
                        else
                            CreatePolySpeed();

                    }
                    break;
                case 0x10:
                    
                    break;
                default:
                    {
                        
                        nerr++;
                        errstr= DateTime.Now.ToLongTimeString() + "  No:" + nerr.ToString() + "\n";
                        if (fce >= 0x80)
                        {
                           errstr += "Modbus error:\n Function " + (fce & 0x7f).ToString() + " return error no.:" + Modbus.RespStruc.errorCode.ToString();
                        }
                        else
                            errstr += "Modbus error:\n unknown function code received";
                    }
                    break;
                  
            }
            COMMAND = false;


        }

        public void vals()
        {
            fa0 = sum0 / i;
            fa1 = sum1 / i;
            string str0 = fa0.ToString("000.00");
            string str1 = fa1.ToString("000.00");
            if ((bool)V.IsChecked)
                {
                 Vx.Content = "Vx=" + str0 + "m/s";
                 Vy.Content = "Vy=" + str1 + "m/s";
            }
                else if ((bool)(VM.IsChecked))
            {
                Vx.Content = "Vm=" + str0 + "m/s";
                Vy.Content = "angle=" + str1 + "°";
            }
            else
            {
                Vx.Content = "";
                Vy.Content = "";
            }
        }


    }


}
